
package ee.ut.mohan.coapserver;
public interface MessageReceiver {
	
	public void receiveMessage(Message msg);

}
