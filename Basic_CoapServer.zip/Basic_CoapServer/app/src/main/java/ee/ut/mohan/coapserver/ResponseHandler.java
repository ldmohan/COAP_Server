package ee.ut.mohan.coapserver;

public interface ResponseHandler {
	void handleResponse(Response response);
}
