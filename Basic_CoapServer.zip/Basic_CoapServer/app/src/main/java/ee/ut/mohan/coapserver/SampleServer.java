package ee.ut.mohan.coapserver;

import java.net.SocketException;

//*************************************

//*************************************


/*
 * This class implements a simple CoAP server for testing purposes.
 * 
 * Currently, it just provides some simple resources.
 *  
 * @author Dominique Im Obersteg & Daniel Pauli
 * @version 0.1
 * 
 */
public class SampleServer extends LocalEndpoint {
	String filename="";
	/*
	 * Constructor for a new SampleServer
	 * 
	 */
	public SampleServer() throws SocketException {
		//this.filename=fname;
		// add resources to the server
		//addResource(new HelloWorldResource());
		addResource(new GetTmpResource());
		//	addResource(new StorageResource());
		//addResource(new ToUpperResource());


		//addResource(new SeparateResource());
	}

	// Resource definitions ////////////////////////////////////////////////////

	/*
	 * Defines a resource that returns "Hello World!" on a GET request.
	 * 
	 */
/*	private class HelloWorldResource extends ReadOnlyResource {
		
		public HelloWorldResource() {
			super("helloWorld");
			setResourceName("GET a friendly greeting!");
		}
		
		@Override
		public void performGET(GETRequest request) {

			// create response
			Response response = new Response(CodeRegistry.RESP_CONTENT);
			
			// set payload
			response.setPayload("Hello World! Some umlauts: äöü");
			
			// complete the request
			request.respond(response);
		}
	}*/
//*************************************************************	
	private class GetTmpResource extends ReadOnlyResource {

		public GetTmpResource() {
			super("getTmpSensor");
			setResourceName("GET Tmp Sensor Value");
		}

		@Override
		public void performGET(GETRequest request) {


				String data = "30";//"no data";
				Response response = new Response(CodeRegistry.RESP_CONTENT);




				// set payload
				response.setPayload(data);

				// complete the request
				request.respond(response);
				System.out.println("msg  sent  "+data);


		}
	}
//**********************//*************************************************************	*
	

	// Logging /////////////////////////////////////////////////////////////////

	@Override
	public void handleRequest(Request request) {

		// output the request
		System.out.println("Incoming request:");
		request.log();

		// handle the request
		super.handleRequest(request);
	}


	// Application entry point /////////////////////////////////////////////////

	public static void main(String[] args) {

		// create server
		try {

			//	Endpoint server = new SampleServer();

			//	System.out.printf("CoAP Server listening at port %d.\n", server.port());

		} catch (Exception e) {

			System.err.printf("Failed to create CoAP Server : %s\n",
					e.getMessage());
			return;
		}

	}


}