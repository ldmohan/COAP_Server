package ee.ut.mohan.coapserver;

public interface MessageHandler {
	
	public void handleRequest(Request request);
	
	public void handleResponse(Response response);
}
